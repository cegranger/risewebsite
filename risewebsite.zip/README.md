# risewebsite
bootstrap from template



### TO DOs

- [ ] Logos commanditaires
- [ ] Section Platine
- [ ] Ajout historique conception
- [ ] Cleanup

## Platine/Or
- [ ] BRP

## Argent/Bronze
- [X] Pomme F (Carolane & Catherine)
- [X] Moteur Gosselin 
- [X] KISSsoft AG
- [X] SKF
- [X] Siemens
- [ ] Michelin
- [ ] Guru
- [X] Boréas Technologies
- [ ] Waterville TG
- [X] Gurit
- [X] Continental conveyor
- [ ] Bespline
- [X] Devinci
- [ ] Engrenages Sherbrooke inc.
- [ ] J.M Bergeron
- [ ] PTM&W
- [ ] Créatek
- [X] Calogy solutions
- [ ] M2 Innovation
- [ ] Desjardins 360d


